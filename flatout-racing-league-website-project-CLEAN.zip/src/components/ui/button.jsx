import React from "react";
const variants = {
  default: "bg-zinc-100 text-zinc-950 hover:bg-white",
  secondary: "bg-zinc-900 text-zinc-100 hover:bg-zinc-800",
  ghost: "bg-transparent text-zinc-200 hover:bg-zinc-900",
};
export function Button({ className = "", variant = "default", ...props }) {
  return (
    <button
      className={
        "inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium transition " +
        "rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-200/20 disabled:opacity-50 disabled:pointer-events-none " +
        (variants[variant] || variants.default) +
        " " +
        className
      }
      {...props}
    />
  );
}
