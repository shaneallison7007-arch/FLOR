import React from "react";
export function Input({ className = "", ...props }) {
  return (
    <input
      className={
        "w-full rounded-2xl border border-zinc-800 bg-zinc-950/40 px-3 py-2 text-sm " +
        "outline-none focus:ring-2 focus:ring-zinc-200/20 " +
        className
      }
      {...props}
    />
  );
}
