# Flatout Racing League Website (Clean Netlify Build)

This version is built to avoid common Netlify build failures:
- No path aliases
- Netlify Node version pinned to 18
- Standard Vite build output to /dist

Netlify settings:
- Base directory: (blank)
- Build command: npm run build
- Publish directory: dist
